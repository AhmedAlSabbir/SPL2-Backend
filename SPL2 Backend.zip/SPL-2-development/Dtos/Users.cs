namespace JWTApi.Dtos
{
    public class Users
    {
         public string Username { get; set; }
         public string Firstname { get; set; }
         public string Lastname {get; set; }
         public string Contrct {get; set; }
         public string Registration { get; set; }


    }
}