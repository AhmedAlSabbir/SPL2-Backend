namespace JWTApi.Dtos
{
    public class Inventory
    {
        public string Status { get; set; }
        public System.DateTime Date { get; set; }
       
    }
}