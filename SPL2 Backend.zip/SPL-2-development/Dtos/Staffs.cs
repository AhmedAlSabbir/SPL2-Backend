namespace JWTApi.Dtos
{
    public class Staffs
    {
        public string Username { get; set; }
        public string Phone { get; set; }

    }
}