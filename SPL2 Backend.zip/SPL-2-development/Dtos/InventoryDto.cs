namespace JWTApi.Dtos
{
    public class InventoryDto
    {
        public string Status { get; set; }
        public string Date { get; set; }
       
    }
}