namespace JWTApi.Controllers
{
    public class TeacherUserController
    {
        
    }
}